package ind_test;

import java.util.Random;

public class TestMain {

	public static void main(String[] args) {
		
		InputOption OPT = new InputOption(); 
		OPT.LoadInputOption();
	
		/*
		args = new String[2];
		args[0] = "ind_test_input.txt";
		args[1] = "10";
		myFunc.print(String.format("\n%s", args[0]));
		myFunc.print(String.format("\n%d", Integer.valueOf(args[1])));
		*/
		//System.exit(0);
		
		
		Tree myTree = new Tree();
		
		myTree.version = 20220530;	
		System.out.println("Ind_test Version: "+myTree.version);

		myTree.getOption(); //Tree.java
		myTree.LoadSeqFile(myTree.oriSeqFile); // to get taxaNum etc..., this function will be called again
		myTree.doIndTestFromFile(); System.exit(0);
		



	}

}
