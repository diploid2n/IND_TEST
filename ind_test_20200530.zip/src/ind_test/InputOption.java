package ind_test;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Scanner;
import java.util.Vector;

public class InputOption {
	
	public String oriSeqFile;
	public ModelType subsModel;
	public ModelType aamModel1, aamModel2;
	public DataType dataType;
	public double aamRatio, aamRatioLBound, aamRatioRBound; 
	public JobType myJob;
	public FreqType myFreqOpt;
	public CodonType codonTableOpt;
	public BootstrapType bootTypeOpt;
	public GapPropMultFactorType gapPropMultFactorOpt;
	public String oriTopo;
	public int randSeed, randomInitialTrees, simulLength, bootIter; // simulTaxa, 
	//simulLength2,extremelyLargeLength,
	public int simulLengthTimes, simulLengthTimes2;
	public int totalNumThread, maxSimulThread;
	public double nonrandomRatio, initial_alpha;
	public int shortBrConstraint, CIforBoundaryCheck;

	public Vector<String> optString;
	
	double[] rateParam;
	
	
	public void LoadInputOption() {
		//LoadInputOption_test12("options_20210619.txt");
		//LoadInputOption_test12("options_20210815.txt");
		LoadInputOption_distribute("ind_test_option.txt");
	}
	

	
	public void LoadInputOption_distribute(String filename) {
		//System.out.println("LoadInputOption(..)..");
		FileInputStream fis = null;
		optString = new Vector<String>(); 

		// seo (20210630)
		// minor options are deleted from options_20210619.txt
		// and are replaced with defaults. 
		totalNumThread = 1;
		initial_alpha = 1.0;
		
		this.rateParam = new double[6];
		int i;
		for (i=0;i<rateParam.length;i++) {
			rateParam[i] = 1.0;
		}
		gapPropMultFactorOpt = GapPropMultFactorType.NocalcGapPropMultFactor;
		simulLengthTimes = 1;
		
		
		try {
			fis = new FileInputStream(filename);

			Scanner scanner = new Scanner(fis);
			int k = 0;
			int totOption = 3;
			
			loop:
			while(scanner.hasNextLine()) {
				String str = scanner.nextLine();
				//System.out.println(str);
				optString.add(str);
				char c;
				i = 0;
				do {
					c = str.charAt(i);
					i++;
				} while (c != '<');
				String str2 = "";				
				do {
					c = str.charAt(i);
					if (Character.isLetterOrDigit(c)) {
						c = Character.toLowerCase(c);
						str2 = str2 + c;
					}
					i++;
				} while (c != '>');
				str = str.substring(i, str.length());
				str = str.trim();
				String[] splitStr = str.split("\\s+");
				str = splitStr[0]; 
	
				if (str2.equals("seqfile")) {
					oriSeqFile = str;
					//System.out.println(str);
					k++;
				}
				else if (str2.equals("bootiter")) {
					bootIter = Integer.valueOf(str);
					//System.out.println(str);
					k++; 
				}
				else if (str2.equals("randseed")) {
					randSeed = Integer.valueOf(str);
					//System.out.println(str);
					k++; 
				}

				if (k == totOption) 
					break loop;
		
	
			}

	
			scanner.close();	
			
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
	}

	
	public void LoadInputOption_test12(String filename) {
		//System.out.println("LoadInputOption(..)..");
		FileInputStream fis = null;
		optString = new Vector<String>(); 
		
		try {
			fis = new FileInputStream(filename);

			Scanner scanner = new Scanner(fis);
			int k = 0;
			int totOption = 19;
			
			loop:
			while(scanner.hasNextLine()) {
				String str = scanner.nextLine();
				//System.out.println(str);
				optString.add(str);
				int i;
				char c;
				i = 0;
				do {
					c = str.charAt(i);
					i++;
				} while (c != '<');
				String str2 = "";				
				do {
					c = str.charAt(i);
					if (Character.isLetterOrDigit(c)) {
						c = Character.toLowerCase(c);
						str2 = str2 + c;
					}
					i++;
				} while (c != '>');
				str = str.substring(i, str.length());
				str = str.trim();
				String[] splitStr = str.split("\\s+");
				str = splitStr[0]; 
	
				if (str2.equals("seqfile")) {
					oriSeqFile = str;
					//System.out.println(str);
					k++;
				}
				else if (str2.equals("subsmodel")) {
					subsModel = ModelType.valueOf(str.toUpperCase()); 
					//System.out.println(str);
					k++;
				}
				else if (str2.equals("aamsub")) {
					this.aamModel1 =  ModelType.valueOf(splitStr[0].toUpperCase());
					this.aamModel2 =  ModelType.valueOf(splitStr[1].toUpperCase());
					this.aamRatio = Double.valueOf(splitStr[2]);
					this.aamRatioLBound = Double.valueOf(splitStr[3]);
					this.aamRatioRBound = Double.valueOf(splitStr[4]);
					k++;
					//////
				}
				else if (str2.equals("freqoption")) { 
					myFreqOpt = FreqType.valueOf(str.toUpperCase()); 
					//System.out.println(str);
					k++;
				}
				else if (str2.equals("codontable")) { 
					codonTableOpt = CodonType.valueOf(str.toUpperCase()); 
					//System.out.println(str);
					k++;
				}
				else if (str2.equals("randseed")) {
					randSeed = Integer.valueOf(str);
					//System.out.println(str);
					k++; 
				}
				
				/*					
				else if (str2.equals("nonrandomratio")) {
					nonrandomRatio = Double.valueOf(str);
					System.out.println(str);
					k++;
				}
				else if (str2.equals("randominitialtrees")) {
					randomInitialTrees = Integer.valueOf(str);
					System.out.println(str);
					k++;
				}
				*/
				else if (str2.equals("treetopo")) {
					//oriTopo = str;
					//System.out.println(str);

					// if tree topology is separated with space, it is merged.
					// paml's output topology is spaced. 
					String tmpStr = String.format("");
					for (int j=0;j<splitStr.length;j++) {
						tmpStr += splitStr[j];
					}
					if (!tmpStr.endsWith(";")) {
						System.err.println("\nSomething wrong in the tree topology of option file");
						System.exit(0);
					}
					oriTopo = tmpStr;
					
					
					
					k++;
				}
				else if (str2.equals("alphaval")) {
					initial_alpha = Double.valueOf(str);
					//System.out.println(str);
					k++;
				}
				else if (str2.equals("rateparam")) {
					this.rateParam = new double[6];
					for (i=0;i<rateParam.length;i++) {
						rateParam[i] = Double.valueOf(splitStr[i]);
					}
					//System.out.println(str);
					k++; 
				}
				else if (str2.equals("job")) {
					//myJob = JobType.valueOf(str);
					int id = Integer.valueOf(str);
					if (id== -5) myJob = JobType.TTTTT_BOOT;
					else if (id== -4) myJob = JobType.CLUSTERING;
					else if (id== -3) myJob = JobType.ML_TREE_EST;
					else if (id== -2) myJob = JobType.SITEWISE_LOGLIKE_ANAL;
					else if (id== -1) myJob = JobType.INDEL_SUBS_DEPENDENCY;
					//else if (id==0) myJob = JobType.EST_HESS_ESL;
					//else if (id==1) myJob = JobType.READ_INFO_PAML;
					else if (id==2) myJob = JobType.EST_BR_HESS_ESL; 					
					else if (id==3) myJob = JobType.READ_INFO;
					else if (id==4) myJob = JobType.READ_INFO_PAML;
					else if (id==5) myJob = JobType.SIMUL;
					else if (id==6) myJob = JobType.INDEL_SUBS_TEST;
					//System.out.println(str);
					k++;
				}
				else if (str2.equals("simullength")) {
					simulLength = Integer.valueOf(str);
					simulLengthTimes = Integer.valueOf(splitStr[1]) ;
					/*
					if (simulLengthTimes != 1) {
						System.err.print(String.format("\nSimulLengthTimes should be 1"));
						System.exit(0);
					}
					*/
					simulLengthTimes2 = Integer.valueOf(splitStr[2]) ;
					//System.out.println(str+" "+splitStr[1]);
					k++; 
				}
				else if (str2.equals("shortbrconstraint")) {
					this.shortBrConstraint = Integer.valueOf(str);
					if (shortBrConstraint != 0 && shortBrConstraint != 1 && shortBrConstraint != 2) {
						System.err.println("\nOnly 0 or 1 or 2 option is required in <short br constraint> option file");
						System.exit(0);
					}
					//System.out.println(str);
					k++; 
				}
				else if (str2.equals("ciforboundarycheck")) {
					this.CIforBoundaryCheck = Integer.valueOf(str);
					//System.out.println(str);
					k++; 
				}
				else if (str2.equals("bootiter")) {
					bootIter = Integer.valueOf(str);
					//System.out.println(str);
					k++; 
				}
				else if (str2.equals("bootstraptype")) {
					int id = Integer.valueOf(str);
					if (id==0) bootTypeOpt = BootstrapType.RELLBoot; 
					else if (id==1) bootTypeOpt = BootstrapType.FullBoot; 
					else;
					//System.out.println(str);
					k++; 
				} 
				else if (str2.equals("gappropmultfactor")) {
					int id = Integer.valueOf(str);
					if (id==0) gapPropMultFactorOpt = GapPropMultFactorType.NocalcGapPropMultFactor;
					else if (id==1) gapPropMultFactorOpt = GapPropMultFactorType.CalcGapPropMultFactor;
					else;
					//System.out.println(str);
					k++; 
				}				
				else if (str2.equals("thread")) {
					totalNumThread = Integer.valueOf(str);
					if (totalNumThread!=1) {
						System.err.print(String.format("\n\nCheck variance calculation parts. This has not been confirmed yet."));
						System.exit(0);
					}
					maxSimulThread = Integer.valueOf(splitStr[1]) ;
					//System.out.println(str);
					k++; 
				}
				else if (str2.equals("additional")) {
					myFunc.propInsertedGap = Double.valueOf(splitStr[0]);
					myFunc.propIncorrectAlign  = Double.valueOf(splitStr[1]);
					myFunc.DxDySize = Integer.valueOf(splitStr[2]);
					//System.out.println(str);
					k++; 
				}
				else if (str2.equals("additional2")) {
					myFunc.statIter = Integer.valueOf(splitStr[0]);
					myFunc.bootIter = Integer.valueOf(splitStr[1]);
					//System.out.println(str);
					k++; 
				}
				else {
					System.err.print(String.format("\nAll options should come first in option_xxxx.txt file....%s",str2));
					System.exit(0);
				}
				
				if (k == totOption) 
					break loop;
		
	
			}

	
			scanner.close();	
			
		}
		catch (IOException e) {
			System.out.println(e);
		} finally {
			try {
				fis.close();
			} catch (IOException e) {
				System.out.println(e);
			} catch (NullPointerException e) {
				System.out.println(e);
			}
		}
	}

}
