package ind_test;

import java.util.Arrays;

public class Node {
	Node desNd; //des_ptr;
	Node isoNd;
	Node isoBig;
	
	int totDesTaxaNum;
	int totDesNodeNum; 
	int nodeNum;
	int idxBranchTopo;
	
	
	double bootProb, branchLength;
	
	String taxonName;
	
	double[] subLikelihood; //[rate_cat][patternCnt][dim=4,20,61]
	
	int[] randSequence;
	int[] randGammaCate;

	boolean recalNeeded;
	
	String treeTopo;

	int clusterID;
	
	public Node() {
		isoNd = null;
		desNd = null;
		isoBig = null;
		idxBranchTopo = -1;
		branchLength = myFunc.BRANCH_LENGTH_LOWER_LIMIT;
		bootProb = -1.0; // initial value is negative
		taxonName = "";
		recalNeeded = true;
		clusterID = -1;
		

	}
	
	public Node traverse() {
		Node ret;
		if (this.desNd.isoNd != null) 
			ret = this.desNd.isoNd;
		else {
			ret = this.isoNd;
		}
		return ret;
	}
	
	public String getTreeTopo() {
		if (this.desNd.isoNd == null) {
			this.treeTopo = this.desNd.taxonName;
		}
		else {
			this.desNd.isoNd.getTreeTopo();
			this.desNd.isoNd.isoNd.getTreeTopo();
			String strA, strB;
			strA = desNd.isoNd.treeTopo;
			strB = desNd.isoNd.isoNd.treeTopo;
			
			if (strA.compareTo(strB)<0) 
				treeTopo = "(" + strA + "," + strB + ")";
			else
				treeTopo = "(" + strB + "," + strA + ")";
		}
		return treeTopo;
	}
	
	public String[] getTaxaList() {
		String[] taxaList = null;
		if (this.desNd.isoNd == null) {
			taxaList = myFunc.addToEnd(taxaList, this.desNd.taxonName);
		}
		else {
			taxaList = this.desNd.isoNd.getTaxaList();
			Arrays.sort(taxaList);
			String[] taxaList2 = null;
			taxaList2 = this.desNd.isoNd.isoNd.getTaxaList();
			int i;
			for (i=0;i<taxaList2.length;i++) 
				taxaList = myFunc.addToEnd(taxaList, taxaList2[i]);
			Arrays.sort(taxaList);
		}
		
		return taxaList;
		
	}

}
