Gap should be one of '-', '?', or '.' and should not be 'N'

