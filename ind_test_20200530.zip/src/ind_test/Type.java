package ind_test;

enum ModelType {
    JC, TN93, GTR, DNAM, WAG, MTREV24, LG, JONES, DAYHOFF, AAM, GY94, SKP1LG, SKP2LG, STLG, STWAG
}

enum DataType {
	DNA, AA
}

enum JobType {
	CLUSTERING,
	ML_TREE_EST,
	SITEWISE_LOGLIKE_ANAL, 
	INDEL_SUBS_DEPENDENCY, 
	EST_BR_HESS, 
	EST_HESS_ESL, 
	EST_BR_HESS_ESL, 
	READ_INFO, 
	READ_INFO_PAML, 
	SIMUL, 
	INDEL_SUBS_TEST,
	TTTTT_BOOT
}

enum FreqType {
	DATAFREQ, MODELFREQ
}
//0: EstBrHess, 1: EstHess, 2:EstPSL, 3: Simul

enum CodonType {
	STD, MAMMT
}

enum BootstrapType {
	RELLBoot, FullBoot
}

enum GapPropMultFactorType {
	NocalcGapPropMultFactor, CalcGapPropMultFactor
}

public class Type { 

}
