Gap should be one of '-', '?', r '.' and should not be 'N'

